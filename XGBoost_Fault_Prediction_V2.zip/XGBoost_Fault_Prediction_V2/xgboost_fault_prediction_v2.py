# ============================================================
# XGBOOST V2 - ENGINE FAULT CLASSIFICATION
# 40 chronological training records + 10 chronological test records
# Adds 5-fold cross-validation on training data and better metrics.
# ============================================================

import os
import json
import warnings

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import xgboost as xgb

from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report,
    confusion_matrix
)

warnings.filterwarnings("ignore")

# ------------------------------------------------------------
# 1. CONFIGURATION
# ------------------------------------------------------------

RANDOM_STATE = 42
TRAIN_RECORDS = 40
TEST_RECORDS = 10
CV_FOLDS = 5

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "Sample(1).xlsx")
OUTPUT_DIR = os.path.join(BASE_DIR, "xgboost_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

FEATURES = [
    "Shaft_RPM",
    "Engine_Load",
    "Fuel_Flow",
    "Air_Pressure",
    "Ambient_Temp",
    "Oil_Temp",
    "Vibration_X",
    "Vibration_Y",
    "Cylinder1_Pressure",
    "Cylinder2_Pressure"
]
TARGET = "Fault_Label"


# ------------------------------------------------------------
# 2. LOAD DATA
# ------------------------------------------------------------

print("\nLoading dataset...")
df = pd.read_excel(DATA_PATH)

required_columns = ["Timestamp"] + FEATURES + [TARGET]
missing_columns = [c for c in required_columns if c not in df.columns]
if missing_columns:
    raise ValueError(f"Missing columns in dataset: {missing_columns}")

df["Timestamp"] = pd.to_datetime(df["Timestamp"], errors="coerce")
for column in FEATURES + [TARGET]:
    df[column] = pd.to_numeric(df[column], errors="coerce")

df = (
    df.dropna(subset=required_columns)
      .sort_values("Timestamp")
      .reset_index(drop=True)
)

expected_records = TRAIN_RECORDS + TEST_RECORDS
if len(df) != expected_records:
    raise ValueError(
        f"This version expects {expected_records} valid records "
        f"({TRAIN_RECORDS} train + {TEST_RECORDS} test), "
        f"but found {len(df)}. Check the dataset or update the split."
    )

if not np.all(np.equal(df[TARGET], np.floor(df[TARGET]))):
    raise ValueError("Fault_Label must contain integer class labels.")

df[TARGET] = df[TARGET].astype(int)

print("\nDATASET SUMMARY")
print("Total valid records:", len(df))
print("Number of sensor features:", len(FEATURES))
print("\nOverall class distribution:")
print(df[TARGET].value_counts().sort_index())


# ------------------------------------------------------------
# 3. CHRONOLOGICAL TRAIN / TEST SPLIT
# ------------------------------------------------------------
# First 40 timestamps are used for training.
# Last 10 timestamps are held out for final testing.
# Do not use the test set to tune model parameters.

train_df = df.iloc[:TRAIN_RECORDS].copy()
test_df = df.iloc[TRAIN_RECORDS:].copy()

X_train = train_df[FEATURES]
X_test = test_df[FEATURES]
y_train_original = train_df[TARGET]
y_test_original = test_df[TARGET]

print("\nDATA SPLIT")
print(f"Training records: {len(train_df)}")
print(f"Testing records : {len(test_df)}")
print("Split ratio     : 40:10 (80:20)")
print("\nTraining class distribution:")
print(y_train_original.value_counts().sort_index())
print("\nTesting class distribution:")
print(y_test_original.value_counts().sort_index())


# ------------------------------------------------------------
# 4. ENCODE TARGET LABELS
# ------------------------------------------------------------

label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(y_train_original)
known_classes = label_encoder.classes_

unseen_test_classes = sorted(
    set(y_test_original.unique()) - set(known_classes)
)
if unseen_test_classes:
    raise ValueError(
        "The test set contains fault classes absent from training: "
        f"{unseen_test_classes}. The model cannot learn unseen classes."
    )

number_of_classes = len(known_classes)
if number_of_classes < 2:
    raise ValueError("At least two fault classes are required.")

class_counts = pd.Series(y_train).value_counts()
if class_counts.min() < CV_FOLDS:
    raise ValueError(
        f"Each class needs at least {CV_FOLDS} training examples "
        "for the selected stratified cross-validation."
    )


# ------------------------------------------------------------
# 5. DEFINE A CONSERVATIVE XGBOOST MODEL
# ------------------------------------------------------------
# Shallower trees and regularization help reduce overfitting
# on this small dataset. These settings are a starting point,
# not guaranteed optimal hyperparameters.

model = xgb.XGBClassifier(
    objective="multi:softprob",
    num_class=number_of_classes,
    n_estimators=100,
    max_depth=2,
    learning_rate=0.03,
    subsample=0.8,
    colsample_bytree=0.8,
    min_child_weight=2,
    reg_lambda=5.0,
    reg_alpha=0.1,
    eval_metric="mlogloss",
    random_state=RANDOM_STATE,
    n_jobs=-1
)


# ------------------------------------------------------------
# 6. 5-FOLD CROSS-VALIDATION ON TRAINING RECORDS ONLY
# ------------------------------------------------------------
# This is a stability check using only the first 40 records.
# It does not replace the final untouched 10-record test.

print("\nStarting 5-fold cross-validation on training data...")

cv = StratifiedKFold(
    n_splits=CV_FOLDS,
    shuffle=True,
    random_state=RANDOM_STATE
)

scoring = {
    "accuracy": "accuracy",
    "balanced_accuracy": "balanced_accuracy",
    "macro_f1": "f1_macro"
}

cv_results = cross_validate(
    model,
    X_train,
    y_train,
    cv=cv,
    scoring=scoring,
    return_train_score=False,
    n_jobs=1
)

cv_summary = {}
print("\nCROSS-VALIDATION RESULTS")
for metric in scoring:
    values = cv_results[f"test_{metric}"]
    mean_value = float(np.mean(values))
    std_value = float(np.std(values))
    cv_summary[metric] = {
        "fold_scores": [float(v) for v in values],
        "mean": mean_value,
        "std": std_value
    }
    print(
        f"{metric}: {mean_value:.4f} "
        f"+/- {std_value:.4f}"
    )


# ------------------------------------------------------------
# 7. TRAIN FINAL MODEL ON ALL 40 TRAINING RECORDS
# ------------------------------------------------------------

print("\nTraining final XGBoost model...")
model.fit(X_train, y_train)
print("Training completed.")


# ------------------------------------------------------------
# 8. PREDICT THE 10 HELD-OUT TEST RECORDS
# ------------------------------------------------------------

predicted_encoded = model.predict(X_test)
predicted_labels = label_encoder.inverse_transform(predicted_encoded)

probabilities = model.predict_proba(X_test)
confidence = np.max(probabilities, axis=1)


# ------------------------------------------------------------
# 9. FINAL TEST METRICS
# ------------------------------------------------------------

accuracy = accuracy_score(y_test_original, predicted_labels)
balanced_accuracy = balanced_accuracy_score(
    y_test_original, predicted_labels
)
macro_precision = precision_score(
    y_test_original, predicted_labels,
    average="macro", zero_division=0
)
macro_recall = recall_score(
    y_test_original, predicted_labels,
    average="macro", zero_division=0
)
macro_f1 = f1_score(
    y_test_original, predicted_labels,
    average="macro", zero_division=0
)

print("\n========================================")
print("XGBOOST V2 - FINAL TEST RESULTS")
print("========================================")
print(f"Accuracy          : {accuracy:.4f} ({accuracy * 100:.2f}%)")
print(f"Balanced accuracy : {balanced_accuracy:.4f}")
print(f"Macro precision   : {macro_precision:.4f}")
print(f"Macro recall      : {macro_recall:.4f}")
print(f"Macro F1-score    : {macro_f1:.4f}")

report_dict = classification_report(
    y_test_original,
    predicted_labels,
    labels=known_classes,
    output_dict=True,
    zero_division=0
)
print("\nCLASSIFICATION REPORT")
print(
    classification_report(
        y_test_original,
        predicted_labels,
        labels=known_classes,
        zero_division=0
    )
)


# ------------------------------------------------------------
# 10. CONFUSION MATRIX
# ------------------------------------------------------------

cm = confusion_matrix(
    y_test_original,
    predicted_labels,
    labels=known_classes
)

plt.figure(figsize=(8, 6))
sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=known_classes,
    yticklabels=known_classes
)
plt.title("XGBoost V2 - Fault Prediction Confusion Matrix")
plt.xlabel("Predicted Fault")
plt.ylabel("Actual Fault")
plt.tight_layout()
plt.savefig(
    os.path.join(OUTPUT_DIR, "confusion_matrix_xgboost_v2.png"),
    dpi=160
)
plt.close()


# ------------------------------------------------------------
# 11. FEATURE IMPORTANCE
# ------------------------------------------------------------

importance_df = pd.DataFrame({
    "Sensor_Parameter": FEATURES,
    "Importance": model.feature_importances_
}).sort_values("Importance", ascending=False)

print("\nFEATURE IMPORTANCE")
print(importance_df.to_string(index=False))

plt.figure(figsize=(9, 6))
plt.barh(
    importance_df["Sensor_Parameter"],
    importance_df["Importance"]
)
plt.gca().invert_yaxis()
plt.title("XGBoost V2 - Sensor Feature Importance")
plt.xlabel("Importance")
plt.ylabel("Sensor Parameters")
plt.tight_layout()
plt.savefig(
    os.path.join(OUTPUT_DIR, "feature_importance_xgboost_v2.png"),
    dpi=160
)
plt.close()


# ------------------------------------------------------------
# 12. SAVE PREDICTIONS AND REPORTS
# ------------------------------------------------------------

prediction_df = pd.DataFrame({
    "Timestamp": test_df["Timestamp"].values,
    "Actual_Fault": y_test_original.values,
    "Predicted_Fault": predicted_labels,
    "Confidence": confidence,
    "Correct": y_test_original.values == predicted_labels
})

prediction_df.to_csv(
    os.path.join(OUTPUT_DIR, "test_predictions_xgboost_v2.csv"),
    index=False
)

importance_df.to_csv(
    os.path.join(OUTPUT_DIR, "feature_importance_xgboost_v2.csv"),
    index=False
)

pd.DataFrame(report_dict).transpose().to_csv(
    os.path.join(OUTPUT_DIR, "classification_report_xgboost_v2.csv")
)

with open(
    os.path.join(OUTPUT_DIR, "cross_validation_results.json"),
    "w",
    encoding="utf-8"
) as file:
    json.dump(cv_summary, file, indent=4)

metrics = {
    "train_records": TRAIN_RECORDS,
    "test_records": TEST_RECORDS,
    "split_ratio": "80:20",
    "test_accuracy": float(accuracy),
    "test_balanced_accuracy": float(balanced_accuracy),
    "test_macro_precision": float(macro_precision),
    "test_macro_recall": float(macro_recall),
    "test_macro_f1": float(macro_f1),
    "cross_validation": cv_summary
}

with open(
    os.path.join(OUTPUT_DIR, "evaluation_metrics.json"),
    "w",
    encoding="utf-8"
) as file:
    json.dump(metrics, file, indent=4)


# ------------------------------------------------------------
# 13. SAVE MODEL AND LABEL ENCODER
# ------------------------------------------------------------

model.save_model(
    os.path.join(OUTPUT_DIR, "xgboost_fault_model_v2.json")
)
joblib.dump(
    label_encoder,
    os.path.join(OUTPUT_DIR, "label_encoder_xgboost_v2.pkl")
)


# ------------------------------------------------------------
# 14. FINAL SUMMARY
# ------------------------------------------------------------

print("\nTEST PREDICTIONS")
print(prediction_df.to_string(index=False))

print("\n========================================")
print("XGBOOST V2 PIPELINE COMPLETED")
print("========================================")
print(f"Training records : {TRAIN_RECORDS}")
print(f"Testing records  : {TEST_RECORDS}")
print(f"Test accuracy    : {accuracy * 100:.2f}%")
print(f"Test macro F1    : {macro_f1:.4f}")
print("Output folder    :", OUTPUT_DIR)
print("\nGenerated output files:")
print("1. xgboost_fault_model_v2.json")
print("2. label_encoder_xgboost_v2.pkl")
print("3. confusion_matrix_xgboost_v2.png")
print("4. feature_importance_xgboost_v2.png")
print("5. test_predictions_xgboost_v2.csv")
print("6. classification_report_xgboost_v2.csv")
print("7. cross_validation_results.json")
print("8. evaluation_metrics.json")

print(
    "\nNOTE: The final test contains only 10 records. "
    "Treat its metrics as preliminary, not as a reliable estimate "
    "of real-world performance."
)
