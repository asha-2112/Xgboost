XGBOOST V2 - ENGINE FAULT PREDICTION

Files:
- Sample(1).xlsx: original 50-record dataset
- xgboost_fault_prediction_v2.py: updated training/evaluation code
- xgboost_outputs/: generated model, metrics, predictions and plots

Install dependencies:
    python -m pip install xgboost pandas numpy openpyxl scikit-learn matplotlib seaborn joblib

Run:
    python xgboost_fault_prediction_v2.py

Split:
- First 40 chronological records: training
- Last 10 chronological records: final testing
- 5-fold stratified cross-validation is performed only within the 40 training records.
- The final 10 test records are not used for model tuning.

V2 changes:
- Shallower trees and stronger regularization to reduce overfitting risk.
- 5-fold cross-validation on training data.
- Accuracy, balanced accuracy, macro precision, macro recall and macro F1.
- Confusion matrix, feature importance, class report and saved metrics.
- Model and label encoder saved separately.

Important:
The dataset contains only 50 records. A 10-record test set is too small to establish
reliable real-world performance. Cross-validation helps assess stability but does not
create new independent data. Feature importance indicates model reliance, not causality.
